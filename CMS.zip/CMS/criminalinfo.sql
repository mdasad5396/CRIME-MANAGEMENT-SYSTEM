

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `info` (
  `id` int(5) NOT NULL,
  `name` varchar(25) NOT NULL,
  `offname` varchar(25) NOT NULL,
  `crime` varchar(25) NOT NULL,
  `dob` date NOT NULL,
  `arrDate` date NOT NULL,
  `crimeDate` date NOT NULL,
  `sex` varchar(1) NOT NULL,
  `address` varchar(50) NOT NULL,
  `img` blob DEFAULT NULL,
  `more` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



--
-- Table structure for table `officer`
--

CREATE TABLE `officer` (
  `offName` varchar(25) NOT NULL,
  `offID` int(5) NOT NULL,
  `ID` int(5) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `weapon` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uname` varchar(10) NOT NULL,
  `pass` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uname`, `pass`) VALUES
('admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `officer`
--
ALTER TABLE `officer`
  ADD PRIMARY KEY (`offID`);
COMMIT;


